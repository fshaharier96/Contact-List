<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="style/main.css">
    <title>Document</title>
</head>
<body>
<?php
 include_once "header.php";
?>
   <div class="home-container">

     
   </div>
   
   <script src="app/jquery.js"></script>
   <script src="app/header.js"></script>
   <script src="app/home.js"></script>
    
</body>
</html>